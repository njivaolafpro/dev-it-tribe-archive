# Installation:
- installer Node Js
- générer image list: 
`cd node-parser`
`node .`

ça va générer `images.generated.json` file.
Copier la liste ->
- et le coller dans parsedList ( sur main.js )


You can then launch the web part ( `index.html` );